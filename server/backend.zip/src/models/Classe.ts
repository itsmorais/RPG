export enum ClassID {
  Guerreiro = 1,
  Mago = 2,
  Arqueiro = 3,
  Clerigo = 4,
}

export interface Class {
    id: number;
    name: string;
  }
  