import { Jogador } from "./Jogador";

export interface Guilda {
    jogadores: Jogador[];
    totalXP: number;
}