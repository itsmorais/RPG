export interface Jogador {
    id: number;
    name: string;
    class_id: number;
    xp: number;
    confirmed: boolean;
  }
  